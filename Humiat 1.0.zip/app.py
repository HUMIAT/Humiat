
import os
import secrets
import hashlib
import hmac
from datetime import date
from typing import Optional, List, Dict

from fastapi import FastAPI, Request, Form, Depends, HTTPException
from fastapi.responses import HTMLResponse, RedirectResponse
from fastapi.staticfiles import StaticFiles
from fastapi.templating import Jinja2Templates
from sqlalchemy import create_engine, Column, Integer, String, Text, ForeignKey, DateTime, func
from sqlalchemy.orm import declarative_base, sessionmaker, Session, relationship


app = FastAPI(title="HUMIAT", version="1.3.0")

app.mount("/static", StaticFiles(directory="static"), name="static")
templates = Jinja2Templates(directory="templates")

BANCO_URL = os.getenv("DATABASE_URL", "sqlite:///./organiza.db")
if BANCO_URL.startswith("postgres://"):
    BANCO_URL = BANCO_URL.replace("postgres://", "postgresql://", 1)

argumentos_conexao = {"check_same_thread": False} if BANCO_URL.startswith("sqlite") else {}
engine = create_engine(BANCO_URL, connect_args=argumentos_conexao, pool_pre_ping=True)
SessionLocal = sessionmaker(bind=engine, autoflush=False, autocommit=False)
Base = declarative_base()

CHAVE_SESSAO = os.getenv("SECRET_KEY", "troque-esta-chave-no-render")
STATUS_VALIDOS = ["Aberta", "Em andamento", "Aguardando", "Pronta", "Entregue"]
RESPONSAVEIS = ["Junior", "Debora", "Luiz"]
DIAS_SEMANA = [
    ("0", "Segunda"),
    ("1", "Terça"),
    ("2", "Quarta"),
    ("3", "Quinta"),
    ("4", "Sexta"),
    ("5", "Sábado"),
    ("6", "Domingo"),
]


class Usuario(Base):
    __tablename__ = "usuarios"
    id = Column(Integer, primary_key=True)
    nome = Column(String(80), unique=True, nullable=False)
    senha_hash = Column(String(255), nullable=False)
    criado_em = Column(DateTime, server_default=func.now())


class Projeto(Base):
    __tablename__ = "projetos"
    id = Column(Integer, primary_key=True)
    nome = Column(String(140), nullable=False)
    observacao = Column(Text, nullable=True)
    criado_em = Column(DateTime, server_default=func.now())
    missoes = relationship("Missao", back_populates="projeto", cascade="all, delete-orphan")


class Missao(Base):
    """
    Mantive o nome interno Missao para não quebrar banco antigo.
    Na tela, este cadastro aparece como Departamento / Etapa.
    """
    __tablename__ = "missoes"
    id = Column(Integer, primary_key=True)
    projeto_id = Column(Integer, ForeignKey("projetos.id"), nullable=False)
    nome = Column(String(140), nullable=False)
    observacao = Column(Text, nullable=True)
    criado_em = Column(DateTime, server_default=func.now())
    projeto = relationship("Projeto", back_populates="missoes")
    tarefas = relationship("Tarefa", back_populates="missao", cascade="all, delete-orphan")


class Tarefa(Base):
    __tablename__ = "tarefas"
    id = Column(Integer, primary_key=True)
    projeto_id = Column(Integer, ForeignKey("projetos.id"), nullable=False)
    missao_id = Column(Integer, ForeignKey("missoes.id"), nullable=False)
    descricao = Column(Text, nullable=False)  # Na tela este campo aparece como Tarefa.
    responsavel = Column(String(80), nullable=False)
    status = Column(String(30), nullable=False, default="Aberta")
    tipo = Column(String(20), nullable=False, default="unica")
    dias_semana = Column(String(30), nullable=True)
    dependencia_id = Column(Integer, ForeignKey("tarefas.id"), nullable=True)
    observacao = Column(Text, nullable=True)  # Na tela aparece como Descrição opcional.
    criado_em = Column(DateTime, server_default=func.now())
    projeto = relationship("Projeto")
    missao = relationship("Missao", back_populates="tarefas", foreign_keys=[missao_id])
    dependencia = relationship("Tarefa", remote_side=[id])


def get_db():
    db = SessionLocal()
    try:
        yield db
    finally:
        db.close()


def gerar_hash_senha(senha: str, salt: Optional[str] = None) -> str:
    salt = salt or secrets.token_hex(16)
    chave = hashlib.pbkdf2_hmac("sha256", senha.encode("utf-8"), salt.encode("utf-8"), 120_000)
    return f"{salt}${chave.hex()}"


def verificar_senha(senha: str, senha_hash: str) -> bool:
    try:
        salt, hash_salvo = senha_hash.split("$", 1)
    except ValueError:
        return False
    hash_digitado = gerar_hash_senha(senha, salt).split("$", 1)[1]
    return hmac.compare_digest(hash_digitado, hash_salvo)


def criar_assinatura(valor: str) -> str:
    return hmac.new(CHAVE_SESSAO.encode("utf-8"), valor.encode("utf-8"), hashlib.sha256).hexdigest()


def criar_cookie_sessao(nome_usuario: str) -> str:
    return f"{nome_usuario}|{criar_assinatura(nome_usuario)}"


def ler_usuario_cookie(request: Request) -> Optional[str]:
    cookie = request.cookies.get("organiza_sessao")
    if not cookie or "|" not in cookie:
        return None
    nome, assinatura = cookie.rsplit("|", 1)
    if hmac.compare_digest(assinatura, criar_assinatura(nome)):
        return nome
    return None


def usuario_logado(request: Request, db: Session = Depends(get_db)) -> Usuario:
    nome = ler_usuario_cookie(request)
    if not nome:
        raise HTTPException(status_code=307, headers={"Location": "/area-restrita/login"})
    usuario = db.query(Usuario).filter(Usuario.nome == nome).first()
    if not usuario:
        raise HTTPException(status_code=307, headers={"Location": "/area-restrita/login"})
    return usuario


def tarefa_aparece_hoje(tarefa: Tarefa) -> bool:
    if tarefa.status == "Entregue":
        return False
    if tarefa.tipo == "recorrente":
        hoje = str(date.today().weekday())
        return hoje in (tarefa.dias_semana or "").split(",")
    return True


def calcular_percentual_projeto(projeto: Projeto) -> int:
    tarefas = [t for etapa in projeto.missoes for t in etapa.tarefas]
    if not tarefas:
        return 0
    entregues = len([t for t in tarefas if t.status == "Entregue"])
    return round((entregues / len(tarefas)) * 100)


def agrupar_por_projeto(tarefas: List[Tarefa]) -> Dict[str, List[Tarefa]]:
    grupos: Dict[str, List[Tarefa]] = {}
    for tarefa in tarefas:
        grupos.setdefault(tarefa.projeto.nome, []).append(tarefa)
    return grupos


@app.on_event("startup")
def iniciar_banco():
    Base.metadata.create_all(bind=engine)
    db = SessionLocal()
    try:
        senha_padrao = os.getenv("ORGANIZA_SENHA_PADRAO", "humiat123")
        for nome in RESPONSAVEIS:
            existe = db.query(Usuario).filter(Usuario.nome == nome).first()
            if not existe:
                db.add(Usuario(nome=nome, senha_hash=gerar_hash_senha(senha_padrao)))
        db.commit()
    finally:
        db.close()


@app.get("/", response_class=HTMLResponse)
def pagina_inicial(request: Request):
    return templates.TemplateResponse("index.html", {"request": request})


@app.get("/saude")
def saude():
    return {"ok": True, "projeto": "HUMIAT", "modulo": "Organiza", "versao": "3"}


@app.get("/area-restrita/login", response_class=HTMLResponse)
def login(request: Request, erro: str = ""):
    return templates.TemplateResponse("organiza/login.html", {"request": request, "erro": erro})


@app.post("/area-restrita/login")
def entrar(usuario: str = Form(...), senha: str = Form(...), db: Session = Depends(get_db)):
    encontrado = db.query(Usuario).filter(Usuario.nome == usuario.strip()).first()
    if not encontrado or not verificar_senha(senha, encontrado.senha_hash):
        return RedirectResponse("/area-restrita/login?erro=Usuário ou senha inválidos", status_code=303)
    resposta = RedirectResponse("/organiza", status_code=303)
    resposta.set_cookie("organiza_sessao", criar_cookie_sessao(encontrado.nome), httponly=True, samesite="lax")
    return resposta


@app.get("/area-restrita/sair")
def sair():
    resposta = RedirectResponse("/area-restrita/login", status_code=303)
    resposta.delete_cookie("organiza_sessao")
    return resposta


@app.get("/organiza", response_class=HTMLResponse)
def painel(request: Request, responsavel: Optional[str] = None, usuario: Usuario = Depends(usuario_logado), db: Session = Depends(get_db)):
    tarefas = db.query(Tarefa).order_by(Tarefa.criado_em.desc()).all()
    responsavel_painel = responsavel if responsavel in RESPONSAVEIS else usuario.nome
    tarefas_hoje_usuario = [t for t in tarefas if t.responsavel == responsavel_painel and tarefa_aparece_hoje(t)]
    resumo = {status: len([t for t in tarefas if t.responsavel == responsavel_painel and t.status == status]) for status in STATUS_VALIDOS}
    por_responsavel = {nome: len([t for t in tarefas if t.responsavel == nome and tarefa_aparece_hoje(t)]) for nome in RESPONSAVEIS}
    projetos = db.query(Projeto).order_by(Projeto.criado_em.desc()).all()
    percentuais = {p.id: calcular_percentual_projeto(p) for p in projetos}
    return templates.TemplateResponse("organiza/painel.html", {
        "request": request, "usuario": usuario, "responsavel_painel": responsavel_painel,
        "tarefas_hoje_usuario": tarefas_hoje_usuario, "resumo": resumo,
        "por_responsavel": por_responsavel, "projetos": projetos, "percentuais": percentuais,
        "status_validos": STATUS_VALIDOS, "responsaveis": RESPONSAVEIS,
    })


@app.get("/organiza/detalhes/{tipo}/{valor}", response_class=HTMLResponse)
def detalhes(tipo: str, valor: str, request: Request, responsavel: Optional[str] = None, usuario: Usuario = Depends(usuario_logado), db: Session = Depends(get_db)):
    tarefas = db.query(Tarefa).order_by(Tarefa.criado_em.desc()).all()
    titulo = "Tarefas"
    if tipo == "responsavel":
        tarefas = [t for t in tarefas if t.responsavel == valor and tarefa_aparece_hoje(t)]
        titulo = f"Tarefas de {valor}"
    elif tipo == "status":
        tarefas = [t for t in tarefas if t.status == valor]
        if responsavel in RESPONSAVEIS:
            tarefas = [t for t in tarefas if t.responsavel == responsavel]
            titulo = f"{valor} de {responsavel}"
        else:
            titulo = f"Tarefas com status: {valor}"
    elif tipo == "hoje":
        tarefas = [t for t in tarefas if tarefa_aparece_hoje(t)]
        titulo = "Tarefas de hoje"
    else:
        raise HTTPException(status_code=404)
    return templates.TemplateResponse("organiza/detalhes.html", {
        "request": request, "usuario": usuario, "titulo": titulo, "grupos": agrupar_por_projeto(tarefas),
        "status_validos": STATUS_VALIDOS
    })


@app.get("/organiza/projetos/novo", response_class=HTMLResponse)
def novo_projeto(request: Request, usuario: Usuario = Depends(usuario_logado)):
    return templates.TemplateResponse("organiza/projeto_form.html", {"request": request, "usuario": usuario, "projeto": None})


@app.post("/organiza/projetos/novo")
def criar_projeto(nome: str = Form(...), observacao: str = Form(""), usuario: Usuario = Depends(usuario_logado), db: Session = Depends(get_db)):
    db.add(Projeto(nome=nome.strip(), observacao=observacao.strip() or None))
    db.commit()
    return RedirectResponse("/organiza", status_code=303)


@app.get("/organiza/projetos/{projeto_id}/editar", response_class=HTMLResponse)
def editar_projeto(projeto_id: int, request: Request, usuario: Usuario = Depends(usuario_logado), db: Session = Depends(get_db)):
    projeto = db.query(Projeto).filter(Projeto.id == projeto_id).first()
    if not projeto: raise HTTPException(status_code=404)
    return templates.TemplateResponse("organiza/projeto_form.html", {"request": request, "usuario": usuario, "projeto": projeto})


@app.post("/organiza/projetos/{projeto_id}/editar")
def salvar_projeto(projeto_id: int, nome: str = Form(...), observacao: str = Form(""), usuario: Usuario = Depends(usuario_logado), db: Session = Depends(get_db)):
    projeto = db.query(Projeto).filter(Projeto.id == projeto_id).first()
    if not projeto: raise HTTPException(status_code=404)
    projeto.nome = nome.strip()
    projeto.observacao = observacao.strip() or None
    db.commit()
    return RedirectResponse(f"/organiza/projetos/{projeto_id}", status_code=303)


@app.get("/organiza/projetos/{projeto_id}", response_class=HTMLResponse)
def ver_projeto(projeto_id: int, request: Request, usuario: Usuario = Depends(usuario_logado), db: Session = Depends(get_db)):
    projeto = db.query(Projeto).filter(Projeto.id == projeto_id).first()
    if not projeto: raise HTTPException(status_code=404)
    tarefas = db.query(Tarefa).filter(Tarefa.projeto_id == projeto_id).order_by(Tarefa.criado_em.desc()).all()
    percentual = calcular_percentual_projeto(projeto)
    return templates.TemplateResponse("organiza/projeto.html", {
        "request": request, "usuario": usuario, "projeto": projeto, "tarefas": tarefas,
        "percentual": percentual, "status_validos": STATUS_VALIDOS
    })


@app.get("/organiza/projetos/{projeto_id}/missoes/nova", response_class=HTMLResponse)
def nova_missao(projeto_id: int, request: Request, usuario: Usuario = Depends(usuario_logado), db: Session = Depends(get_db)):
    projeto = db.query(Projeto).filter(Projeto.id == projeto_id).first()
    if not projeto: raise HTTPException(status_code=404)
    return templates.TemplateResponse("organiza/missao_form.html", {"request": request, "usuario": usuario, "projeto": projeto, "missao": None})


@app.post("/organiza/projetos/{projeto_id}/missoes/nova")
def criar_missao(projeto_id: int, nome: str = Form(...), observacao: str = Form(""), usuario: Usuario = Depends(usuario_logado), db: Session = Depends(get_db)):
    db.add(Missao(projeto_id=projeto_id, nome=nome.strip(), observacao=observacao.strip() or None))
    db.commit()
    return RedirectResponse(f"/organiza/projetos/{projeto_id}", status_code=303)


@app.get("/organiza/projetos/{projeto_id}/missoes/{missao_id}/editar", response_class=HTMLResponse)
def editar_missao(projeto_id: int, missao_id: int, request: Request, usuario: Usuario = Depends(usuario_logado), db: Session = Depends(get_db)):
    projeto = db.query(Projeto).filter(Projeto.id == projeto_id).first()
    missao = db.query(Missao).filter(Missao.id == missao_id, Missao.projeto_id == projeto_id).first()
    if not projeto or not missao: raise HTTPException(status_code=404)
    return templates.TemplateResponse("organiza/missao_form.html", {"request": request, "usuario": usuario, "projeto": projeto, "missao": missao})


@app.post("/organiza/projetos/{projeto_id}/missoes/{missao_id}/editar")
def salvar_missao(projeto_id: int, missao_id: int, nome: str = Form(...), observacao: str = Form(""), usuario: Usuario = Depends(usuario_logado), db: Session = Depends(get_db)):
    missao = db.query(Missao).filter(Missao.id == missao_id, Missao.projeto_id == projeto_id).first()
    if not missao: raise HTTPException(status_code=404)
    missao.nome = nome.strip()
    missao.observacao = observacao.strip() or None
    db.commit()
    return RedirectResponse(f"/organiza/projetos/{projeto_id}", status_code=303)


@app.get("/organiza/tarefas/nova", response_class=HTMLResponse)
def nova_tarefa(request: Request, projeto_id: Optional[int] = None, missao_id: Optional[int] = None, dependencia_id: Optional[int] = None, usuario: Usuario = Depends(usuario_logado), db: Session = Depends(get_db)):
    projetos = db.query(Projeto).order_by(Projeto.nome).all()
    missoes = db.query(Missao).order_by(Missao.nome).all()
    tarefas = db.query(Tarefa).order_by(Tarefa.criado_em.desc()).all()
    return templates.TemplateResponse("organiza/tarefa_form.html", {
        "request": request, "usuario": usuario, "projetos": projetos, "missoes": missoes, "tarefa": None,
        "tarefas": tarefas, "responsaveis": RESPONSAVEIS, "status_validos": STATUS_VALIDOS,
        "dias_semana": DIAS_SEMANA, "projeto_id": projeto_id, "missao_id": missao_id, "dependencia_id": dependencia_id
    })


@app.post("/organiza/tarefas/nova")
def criar_tarefa(projeto_id: int = Form(...), missao_id: int = Form(...), descricao: str = Form(...), responsavel: str = Form(...), status: str = Form("Aberta"), tipo: str = Form("unica"), dias_semana: Optional[List[str]] = Form(None), dependencia_id: str = Form(""), observacao: str = Form(""), usuario: Usuario = Depends(usuario_logado), db: Session = Depends(get_db)):
    missao = db.query(Missao).filter(Missao.id == missao_id, Missao.projeto_id == projeto_id).first()
    if not missao:
        raise HTTPException(status_code=400, detail="Departamento / Etapa não pertence ao projeto selecionado.")
    dependencia = None
    if dependencia_id:
        dep = db.query(Tarefa).filter(Tarefa.id == int(dependencia_id), Tarefa.projeto_id == projeto_id).first()
        dependencia = dep.id if dep else None
    dias = ",".join(dias_semana or []) if tipo == "recorrente" else None
    db.add(Tarefa(projeto_id=projeto_id, missao_id=missao_id, descricao=descricao.strip(), responsavel=responsavel, status=status, tipo=tipo, dias_semana=dias, dependencia_id=dependencia, observacao=observacao.strip() or None))
    db.commit()
    return RedirectResponse(f"/organiza/projetos/{projeto_id}", status_code=303)


@app.get("/organiza/tarefas/{tarefa_id}/editar", response_class=HTMLResponse)
def editar_tarefa(tarefa_id: int, request: Request, usuario: Usuario = Depends(usuario_logado), db: Session = Depends(get_db)):
    tarefa = db.query(Tarefa).filter(Tarefa.id == tarefa_id).first()
    if not tarefa: raise HTTPException(status_code=404)
    projetos = db.query(Projeto).order_by(Projeto.nome).all()
    missoes = db.query(Missao).order_by(Missao.nome).all()
    tarefas = db.query(Tarefa).filter(Tarefa.id != tarefa_id).order_by(Tarefa.criado_em.desc()).all()
    return templates.TemplateResponse("organiza/tarefa_form.html", {
        "request": request, "usuario": usuario, "projetos": projetos, "missoes": missoes, "tarefa": tarefa,
        "tarefas": tarefas, "responsaveis": RESPONSAVEIS, "status_validos": STATUS_VALIDOS, "dias_semana": DIAS_SEMANA,
        "projeto_id": tarefa.projeto_id, "missao_id": tarefa.missao_id, "dependencia_id": tarefa.dependencia_id
    })


@app.post("/organiza/tarefas/{tarefa_id}/editar")
def salvar_tarefa(tarefa_id: int, projeto_id: int = Form(...), missao_id: int = Form(...), descricao: str = Form(...), responsavel: str = Form(...), status: str = Form("Aberta"), tipo: str = Form("unica"), dias_semana: Optional[List[str]] = Form(None), dependencia_id: str = Form(""), observacao: str = Form(""), usuario: Usuario = Depends(usuario_logado), db: Session = Depends(get_db)):
    tarefa = db.query(Tarefa).filter(Tarefa.id == tarefa_id).first()
    if not tarefa: raise HTTPException(status_code=404)
    missao = db.query(Missao).filter(Missao.id == missao_id, Missao.projeto_id == projeto_id).first()
    if not missao:
        raise HTTPException(status_code=400, detail="Departamento / Etapa não pertence ao projeto selecionado.")
    dependencia = None
    if dependencia_id:
        dep = db.query(Tarefa).filter(Tarefa.id == int(dependencia_id), Tarefa.projeto_id == projeto_id, Tarefa.id != tarefa_id).first()
        dependencia = dep.id if dep else None
    tarefa.projeto_id = projeto_id
    tarefa.missao_id = missao_id
    tarefa.descricao = descricao.strip()
    tarefa.responsavel = responsavel
    tarefa.status = status
    tarefa.tipo = tipo
    tarefa.dias_semana = ",".join(dias_semana or []) if tipo == "recorrente" else None
    tarefa.dependencia_id = dependencia
    tarefa.observacao = observacao.strip() or None
    db.commit()
    return RedirectResponse(f"/organiza/projetos/{projeto_id}", status_code=303)


@app.post("/organiza/tarefas/{tarefa_id}/status")
def alterar_status(tarefa_id: int, status: str = Form(...), voltar: str = Form("/organiza"), usuario: Usuario = Depends(usuario_logado), db: Session = Depends(get_db)):
    tarefa = db.query(Tarefa).filter(Tarefa.id == tarefa_id).first()
    if not tarefa: raise HTTPException(status_code=404)
    if status in STATUS_VALIDOS:
        tarefa.status = status
        db.commit()
    return RedirectResponse(voltar or "/organiza", status_code=303)
